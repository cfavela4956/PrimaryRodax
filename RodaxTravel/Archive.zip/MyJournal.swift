//
//  MyJournal.swift
//  RodaxTravel
//
//  Created by Student on 11/5/20.
//  Copyright © 2020 Student. All rights reserved.
//

import UIKit

class MyJournal: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
}
